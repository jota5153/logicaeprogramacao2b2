﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calculadorafuncional
{
    public partial class frmcalculadora : Form
    {
        public frmcalculadora()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            float valorNumero1 = float.Parse(txtvalor1.Text);
            float valorNumero2 = float.Parse(txtvalor2.Text);
            float soma;

            soma = valorNumero1 + valorNumero2;

            MessageBox.Show("A soma é: " + soma);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            float valorNumero1 = float.Parse(txtvalor1.Text);
            float valorNumero2 = float.Parse(txtvalor2.Text);
            float multiplicacao;

            multiplicacao = valorNumero1 * valorNumero2;

            MessageBox.Show("A multiplicação é: " + multiplicacao);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            float valorNumero1 = float.Parse(txtvalor1.Text);
            float valorNumero2 = float.Parse(txtvalor2.Text);
            float divisao;

            divisao = valorNumero1 / valorNumero2;

            MessageBox.Show("A divisão é: " + divisao);
        }

        private void btnsubtracao_Click(object sender, EventArgs e)
        {
            float valorNumero1 = float.Parse(txtvalor1.Text);
            float valorNumero2 = float.Parse(txtvalor2.Text);
            float subtracao;

            subtracao = valorNumero1 - valorNumero2;

            MessageBox.Show("A subtração é: " + subtracao);
        }
    }
}
