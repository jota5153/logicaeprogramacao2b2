﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace app1
{
    public partial class frmenviomensagem : Form
    {
        public frmenviomensagem()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Carregamento concluído. Clique em OK.");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Botão MOSTRAR operado com sucesso.");
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Um texto da ala INTEIROS foi alterado.");
        }

        private void label2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("A label TEXTO está sendo clicada.");
        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("A label INTEIROS está sendo clicada.");
        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Botão LIMPAR operado com sucesso.");
        }

        private void txtdecimal_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Um texto da ala DECIMAL foi alterado.");
        }

        private void txttexto_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Um texto da ala TEXTOS foi alterado.");
        }

        private void txtbooleano_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Um texto da ala BOOLEANO foi alterado.");
        }

        private void lbldecimal_Click(object sender, EventArgs e)
        {
            MessageBox.Show("A label DECIMAL está sendo clicada.");
        }

        private void lblbooleano_Click(object sender, EventArgs e)
        {
            MessageBox.Show("A label BOOLEANO está sendo clicada.");
        }
    }
}
