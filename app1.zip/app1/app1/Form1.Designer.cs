﻿namespace app1
{
    partial class frmenviomensagem
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnmostrar = new System.Windows.Forms.Button();
            this.btnlimpar = new System.Windows.Forms.Button();
            this.txtbooleano = new System.Windows.Forms.TextBox();
            this.txttexto = new System.Windows.Forms.TextBox();
            this.txtdecimal = new System.Windows.Forms.TextBox();
            this.txtinteiro = new System.Windows.Forms.TextBox();
            this.lblbooleano = new System.Windows.Forms.Label();
            this.lbltexto = new System.Windows.Forms.Label();
            this.lbldecimal = new System.Windows.Forms.Label();
            this.lblinteiro = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnmostrar
            // 
            this.btnmostrar.Location = new System.Drawing.Point(21, 298);
            this.btnmostrar.Name = "btnmostrar";
            this.btnmostrar.Size = new System.Drawing.Size(133, 38);
            this.btnmostrar.TabIndex = 0;
            this.btnmostrar.Text = "MOSTRAR";
            this.btnmostrar.UseVisualStyleBackColor = true;
            this.btnmostrar.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnlimpar
            // 
            this.btnlimpar.Location = new System.Drawing.Point(192, 298);
            this.btnlimpar.Name = "btnlimpar";
            this.btnlimpar.Size = new System.Drawing.Size(133, 38);
            this.btnlimpar.TabIndex = 1;
            this.btnlimpar.Text = "LIMPAR";
            this.btnlimpar.UseVisualStyleBackColor = true;
            this.btnlimpar.Click += new System.EventHandler(this.btnlimpar_Click);
            // 
            // txtbooleano
            // 
            this.txtbooleano.Location = new System.Drawing.Point(21, 251);
            this.txtbooleano.Name = "txtbooleano";
            this.txtbooleano.Size = new System.Drawing.Size(304, 20);
            this.txtbooleano.TabIndex = 2;
            this.txtbooleano.TextChanged += new System.EventHandler(this.txtbooleano_TextChanged);
            // 
            // txttexto
            // 
            this.txttexto.Location = new System.Drawing.Point(21, 182);
            this.txttexto.Name = "txttexto";
            this.txttexto.Size = new System.Drawing.Size(304, 20);
            this.txttexto.TabIndex = 4;
            this.txttexto.TextChanged += new System.EventHandler(this.txttexto_TextChanged);
            // 
            // txtdecimal
            // 
            this.txtdecimal.Location = new System.Drawing.Point(21, 116);
            this.txtdecimal.Name = "txtdecimal";
            this.txtdecimal.Size = new System.Drawing.Size(304, 20);
            this.txtdecimal.TabIndex = 5;
            this.txtdecimal.TextChanged += new System.EventHandler(this.txtdecimal_TextChanged);
            // 
            // txtinteiro
            // 
            this.txtinteiro.Location = new System.Drawing.Point(21, 46);
            this.txtinteiro.Name = "txtinteiro";
            this.txtinteiro.Size = new System.Drawing.Size(304, 20);
            this.txtinteiro.TabIndex = 6;
            this.txtinteiro.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // lblbooleano
            // 
            this.lblbooleano.AutoSize = true;
            this.lblbooleano.BackColor = System.Drawing.SystemColors.InfoText;
            this.lblbooleano.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblbooleano.Location = new System.Drawing.Point(18, 222);
            this.lblbooleano.Name = "lblbooleano";
            this.lblbooleano.Size = new System.Drawing.Size(52, 13);
            this.lblbooleano.TabIndex = 7;
            this.lblbooleano.Text = "Booleano";
            this.lblbooleano.Click += new System.EventHandler(this.lblbooleano_Click);
            // 
            // lbltexto
            // 
            this.lbltexto.AutoSize = true;
            this.lbltexto.BackColor = System.Drawing.SystemColors.InfoText;
            this.lbltexto.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbltexto.Location = new System.Drawing.Point(18, 151);
            this.lbltexto.Name = "lbltexto";
            this.lbltexto.Size = new System.Drawing.Size(34, 13);
            this.lbltexto.TabIndex = 8;
            this.lbltexto.Text = "Texto";
            this.lbltexto.Click += new System.EventHandler(this.label2_Click);
            // 
            // lbldecimal
            // 
            this.lbldecimal.AutoSize = true;
            this.lbldecimal.BackColor = System.Drawing.SystemColors.InfoText;
            this.lbldecimal.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbldecimal.Location = new System.Drawing.Point(18, 81);
            this.lbldecimal.Name = "lbldecimal";
            this.lbldecimal.Size = new System.Drawing.Size(45, 13);
            this.lbldecimal.TabIndex = 9;
            this.lbldecimal.Text = "Decimal";
            this.lbldecimal.Click += new System.EventHandler(this.lbldecimal_Click);
            // 
            // lblinteiro
            // 
            this.lblinteiro.AutoSize = true;
            this.lblinteiro.BackColor = System.Drawing.SystemColors.InfoText;
            this.lblinteiro.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblinteiro.Location = new System.Drawing.Point(18, 18);
            this.lblinteiro.Name = "lblinteiro";
            this.lblinteiro.Size = new System.Drawing.Size(36, 13);
            this.lblinteiro.TabIndex = 10;
            this.lblinteiro.Text = "Inteiro";
            this.lblinteiro.Click += new System.EventHandler(this.label4_Click);
            // 
            // frmenviomensagem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InfoText;
            this.ClientSize = new System.Drawing.Size(341, 385);
            this.Controls.Add(this.lblinteiro);
            this.Controls.Add(this.lbldecimal);
            this.Controls.Add(this.lbltexto);
            this.Controls.Add(this.lblbooleano);
            this.Controls.Add(this.txtinteiro);
            this.Controls.Add(this.txtdecimal);
            this.Controls.Add(this.txttexto);
            this.Controls.Add(this.txtbooleano);
            this.Controls.Add(this.btnlimpar);
            this.Controls.Add(this.btnmostrar);
            this.Name = "frmenviomensagem";
            this.Text = "Envio de mensagens";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnmostrar;
        private System.Windows.Forms.Button btnlimpar;
        private System.Windows.Forms.TextBox txtbooleano;
        private System.Windows.Forms.TextBox txttexto;
        private System.Windows.Forms.TextBox txtdecimal;
        private System.Windows.Forms.TextBox txtinteiro;
        private System.Windows.Forms.Label lblbooleano;
        private System.Windows.Forms.Label lbltexto;
        private System.Windows.Forms.Label lbldecimal;
        private System.Windows.Forms.Label lblinteiro;
    }
}

